import './App.css';
import { BrowserRouter, Routes, Route  } from 'react-router-dom';
import Home from './components/Home';
import Main from './components/Main';
import Testimonial from './components/Testimonial';
import NewArrival from './components/NewArrival';
import Footer from './components/Footer';
import BestSellers from './components/BestSeller';
import Contact from './components/Contact';
import Cart from './components/Cart';
import Genre from './components/Genre/Genre';
import Book1 from './components/Books/book1';

function App() {
  return (
    <BrowserRouter>
      <div className='App'>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/Main" element={<Main/>} />
          <Route path="/Testimonial" element={<Testimonial/>} />
          <Route path="/NewArrival" element={<NewArrival/>} />
          <Route path="/Footer" element={<Footer/>} />
          <Route path="/BestSellers" element={<BestSellers/>} />
          <Route path="/Contact" element={<Contact/>}/>
          <Route path="/Cart" element={<Cart/>}/>
          <Route path="/Genre" element={<Genre/>}/>
          <Route path="/Book1" element={<Book1/>}/>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;

